from flask import Flask, request, render_template
import sqlite3, re

app = Flask(__name__)
DB_PATH = "vuln.db"

LAB_ROUTES = [None, "/lab1", "/lab2", "/lab3", "/lab4",
              "/lab5", "/lab6", "/lab7", "/lab8"]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def nav(lab_num, completed):
    prev_url = LAB_ROUTES[lab_num - 1] if lab_num > 1 else "/"
    next_url = LAB_ROUTES[lab_num + 1] if lab_num < 8 else None
    return dict(lab_num=lab_num, completed=completed,
                prev_url=prev_url, next_url=next_url)

# ── Home ──────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

# ── Lab 1 — WHERE Clause Hidden Data ─────────────────────────────────────────
@app.route("/lab1")
def lab1():
    category = request.args.get("category", "")
    results = error = None
    if category:
        conn = get_db()
        query = (f"SELECT id, name, description, category, released "
                 f"FROM products WHERE category='{category}' AND released=1")
        try:
            results = [dict(r) for r in conn.execute(query).fetchall()]
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when hidden products (released=0) are exposed
    completed = bool(results and any(r.get("released") == 0 for r in results))
    return render_template("lab1_products.html", results=results, error=error,
                           category=category, **nav(1, completed))

# ── Lab 2 — Login Bypass ──────────────────────────────────────────────────────
@app.route("/lab2", methods=["GET", "POST"])
def lab2():
    result = error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        conn = get_db()
        query = (f"SELECT * FROM users WHERE username='{username}'"
                 f" AND password='{password}'")
        try:
            row = conn.execute(query).fetchone()
            result = dict(row) if row else "Invalid credentials."
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when logged in as administrator
    completed = isinstance(result, dict) and result.get("username") == "administrator"
    return render_template("lab2_login.html", result=result, error=error,
                           **nav(2, completed))

# ── Lab 3 — UNION Column Count ────────────────────────────────────────────────
@app.route("/lab3")
def lab3():
    search = request.args.get("q", "")
    results = error = None
    if search:
        conn = get_db()
        query = f"SELECT id, name, description FROM products WHERE name='{search}'"
        try:
            results = [dict(r) for r in conn.execute(query).fetchall()]
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when a UNION NULL row appears (id is None)
    completed = bool(results and any(r.get("id") is None for r in results))
    return render_template("lab3_union.html", results=results, error=error,
                           search=search, **nav(3, completed))

# ── Lab 4 — Find Text Column ──────────────────────────────────────────────────
@app.route("/lab4")
def lab4():
    search = request.args.get("q", "")
    results = error = None
    if search:
        conn = get_db()
        query = f"SELECT id, name, price FROM products WHERE name='{search}'"
        try:
            results = [dict(r) for r in conn.execute(query).fetchall()]
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when 'a' appears in the name column (text column found)
    completed = bool(results and any(str(r.get("name", "")).strip() == "a" for r in results))
    return render_template("lab4_text.html", results=results, error=error,
                           search=search, **nav(4, completed))

# ── Lab 5 — Retrieve Data from Other Tables ───────────────────────────────────
@app.route("/lab5")
def lab5():
    search = request.args.get("q", "")
    results = error = None
    if search:
        conn = get_db()
        query = f"SELECT id, name, description FROM products WHERE name='{search}'"
        try:
            results = [dict(r) for r in conn.execute(query).fetchall()]
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when secret_users credentials appear (known usernames)
    secret_names = {"wiener", "carlos", "root"}
    completed = bool(results and any(
        str(r.get("id", "")).strip().lower() in secret_names for r in results
    ))
    return render_template("lab5_tables.html", results=results, error=error,
                           search=search, **nav(5, completed))

# ── Lab 6 — Multiple Values in One Column ────────────────────────────────────
@app.route("/lab6")
def lab6():
    search = request.args.get("q", "")
    results = error = None
    if search:
        conn = get_db()
        query = f"SELECT id, name, released FROM products WHERE name='{search}'"
        try:
            results = [dict(r) for r in conn.execute(query).fetchall()]
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when concatenated user:pass appears (colon in name column)
    completed = bool(results and any(":" in str(r.get("name", "")) for r in results))
    return render_template("lab6_multi.html", results=results, error=error,
                           search=search, **nav(6, completed))

# ── Lab 7 — DB Version ────────────────────────────────────────────────────────
@app.route("/lab7")
def lab7():
    search = request.args.get("q", "")
    results = error = None
    if search:
        conn = get_db()
        query = f"SELECT id, name, description FROM products WHERE name='{search}'"
        try:
            results = [dict(r) for r in conn.execute(query).fetchall()]
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when version string appears (e.g. "3.39.4" — digits and dots)
    ver_re = re.compile(r"^\d+\.\d+")
    completed = bool(results and any(
        ver_re.match(str(r.get("id", ""))) for r in results
    ))
    return render_template("lab7_version.html", results=results, error=error,
                           search=search, **nav(7, completed))

# ── Lab 8 — List Database Contents ───────────────────────────────────────────
@app.route("/lab8")
def lab8():
    search = request.args.get("q", "")
    results = error = None
    if search:
        conn = get_db()
        query = f"SELECT id, name, description FROM products WHERE name='{search}'"
        try:
            results = [dict(r) for r in conn.execute(query).fetchall()]
        except Exception as e:
            error = str(e)
        conn.close()
    # Completed when known table names appear in results
    known_tables = {"products", "users", "secret_users"}
    completed = bool(results and any(
        str(r.get("id", "")).strip().lower() in known_tables for r in results
    ))
    return render_template("lab8_schema.html", results=results, error=error,
                           search=search, **nav(8, completed))

if __name__ == "__main__":
    import os
    if not os.path.exists(DB_PATH):
        from database import init_db
        init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
