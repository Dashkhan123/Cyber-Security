import sqlite3, os

DB_PATH = "vuln.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.executescript("""
    DROP TABLE IF EXISTS users;
    DROP TABLE IF EXISTS secret_users;
    DROP TABLE IF EXISTS products;

    CREATE TABLE users (
        id       INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role     TEXT NOT NULL DEFAULT 'user'
    );

    CREATE TABLE secret_users (
        id       INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    );

    CREATE TABLE products (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT NOT NULL,
        description TEXT,
        category    TEXT NOT NULL,
        price       INTEGER NOT NULL DEFAULT 0,
        released    INTEGER NOT NULL DEFAULT 1
    );
    """)

    c.executemany("INSERT INTO users (username,password,role) VALUES (?,?,?)", [
        ("administrator", "s3cr3tP@ss!", "admin"),
        ("alice",         "alice123",    "user"),
        ("bob",           "password1",   "user"),
    ])

    c.executemany("INSERT INTO secret_users (username,password) VALUES (?,?)", [
        ("wiener",  "bluecheese"),
        ("carlos",  "montoya"),
        ("root",    "toor1234"),
    ])

    c.executemany(
        "INSERT INTO products (name,description,category,price,released) VALUES (?,?,?,?,?)",
        [
            ("Wireless Headphones", "Noise-cancelling over-ear",   "Electronics", 79,  1),
            ("Mechanical Keyboard", "Tenkeyless, Cherry MX Blue",  "Electronics", 129, 1),
            ("USB-C Hub",           "7-in-1 with HDMI + PD",       "Electronics", 39,  1),
            ("UNRELEASED Earbuds",  "Coming soon — not public",    "Electronics", 59,  0),
            ("Python Book",         "Beginner-friendly guide",     "Books",       29,  1),
            ("Hacking: The Art",    "Kevin Mitnick classic",       "Books",       19,  1),
            ("Secret Roadmap Doc",  "Internal Q3 roadmap",         "Books",        0,  0),
            ("Desk Lamp",           "LED, adjustable temperature", "Office",       24,  1),
            ("Notebook A5",         "Dot-grid, 160 pages",         "Office",        8,  1),
            ("PROTOTYPE Monitor",   "Unreleased 4K display",       "Office",      299,  0),
        ]
    )

    conn.commit()
    conn.close()
    print("✓ vuln.db created — 3 users | 3 secret_users | 10 products (3 hidden)")

if __name__ == "__main__":
    init_db()
